##### References
- K. Black. (2016). _Tactical Barbell 2 Conditioning_. Createspace Independent Publishing Platform.
- Wendler, J. (2017). _5/3/1 forever: Simple and effective programming for size, speed and strength_ (First edition). Jim Wendler LLC.
- Training roadmap [[202303051556 Jamie - Fitness Roadmap 1]]

## Notes
- Strength
- Conditioning
	- Endurance - develop aerobic capacity, mental tolerance to moving
		- Aerobic training: Effective in reducing body fat
			- Improves performance in other fitness domains
			- Increased heart volume (cardiac hypertrophy)
			- Stronger heart contraction
			- Improved vascular network
			- Long-Steady State (LSS) work - prevents HR from getting too high and reducing blood volume benefits
		- Strength endurance
			- Doing 100 push-ups, 24 pull-ups
			- Keeps muscles strong for longer during repetitive activities, such as a day of hiking or walking on the beach
	- High-intensity - Higher work output in short period of time
		- Building cardiac strength
		- Anaerobic training
			- 100-meter sprint
			- Generation of energy/ATP using glycogen (not oxygen)
	- 