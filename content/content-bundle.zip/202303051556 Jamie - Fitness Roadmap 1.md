#training #fitness #health #body 
---
home: true
---
##### References 
- _7 Effective and Easy Workouts for Overweight Beginners_. (2019, August 1). Big Health & Fitness. [https://www.bighealthandfitness.co.uk/easy-workouts-for-overweight-beginners/](https://www.bighealthandfitness.co.uk/easy-workouts-for-overweight-beginners/)
- K. Black. (2016). _Tactical Barbell 2 Conditioning_. Createspace Independent Publishing Platform.Tactical Barbell - Conditioning
- _The 8 Best Exercises for Weight Loss_. (2022, March 31). Healthline. [https://www.healthline.com/nutrition/best-exercise-for-weight-loss](https://www.healthline.com/nutrition/best-exercise-for-weight-loss)
- Wendler, J. (2017). _5/3/1 forever: Simple and effective programming for size, speed and strength_ (First edition). Jim Wendler LLC.
- Training Terminology [[202303051616 Training and Fitness terminology 1]]
## Notes
### Step 1: Pre-Basebuilding: 8 weeks
- Goals: 
	- General endurance
- Strength focus: Strength-endurance
- Training vault:
	- Conditioning
		- Walking
		- Nordic walking after familiarization phase
		- Stationary bike
	- Strength:
		- Calisthenics
			- Modified push-ups: 3 x 10
			- Modified squats: 3 x 10
			- Side leg lifts: 
			- Bridges
			- Jumping jacks
		- Standing long jump
	- Recovery
		- Foam roll
		- Static stretching
### Step 2: Basebuilding: 8 weeks
- Goals:
	- General endurance
	- Strength
- Strength focus: Strength-endurance
- Training vault:
	- Conditioning
		- Walking
		- Run/jog/walk
	- Stationary bike
	- Recovery
		- Foam roll
		- Static stretching
### Step 3: Main training
- Goals:
	- Weight loss
	- Endurance
- Training vault
- 
### Step 4: Maintenance of low-priority fitness
- Goals:
	- Maintain strength